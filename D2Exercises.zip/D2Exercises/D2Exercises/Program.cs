﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace D2Exercises
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("****************Question 1****************");
            Console.Write("Please enter your name: ");
            string name = Console.ReadLine();
            Console.Write("Please enter your gender (M/F): ");
            string gender = Console.ReadLine();

            switch (gender)
            {
                case "M":
                    Console.WriteLine($"Good Morning Mr. {name}");
                    break;

                case "F":
                    Console.WriteLine($"Good Morning Ms. {name}");
                    break;
            }


            Console.WriteLine("****************Question 2****************");
            Console.Write("Please enter your name: ");
            string name2 = Console.ReadLine();
            Console.Write("Please enter your gender (M/F): ");
            string gender2 = Console.ReadLine();
            Console.Write("Please enter your age: ");
            int age = int.Parse(Console.ReadLine());

            if (age >= 40)
            {
                switch (gender2)
                {
                    case "M":
                        Console.WriteLine($"Good Morning Uncle {name2}");
                        break;

                    case "F":
                        Console.WriteLine($"Good Morning Aunty {name2}");
                        break;
                }
            }
            else
            {
                switch (gender2)
                {
                    case "M":
                        Console.WriteLine($"Good Morning Mr. {name2}");
                        break;

                    case "F":
                        Console.WriteLine($"Good Morning Ms. {name2}");
                        break;
                }
            }



            Console.WriteLine("****************Question 3****************");
            Console.Write("Please enter the score: ");
            int score = int.Parse(Console.ReadLine());

            if (score >= 0 && score < 40)
            {
                Console.WriteLine($"Your scored {score} marks which is F grade.");
            }
            else if (score >= 40 && score <= 59)
            {
                Console.WriteLine($"Your scored {score} marks which is C grade.");
            }
            else if (score > 59 && score <= 79)
            {
                Console.WriteLine($"Your scored {score} marks which is B grade.");
            }
            else if (score > 79 && score <= 100)
            {
                Console.WriteLine($"Your scored {score} marks which is A grade.");
            }
            else if (score < 0 || score > 100)
            {
                Console.WriteLine("**Error**");
            }


            Console.WriteLine("****************Question 4****************");
            Console.Write("Please enter the kilometers you travelled: ");
            double meter = double.Parse(Console.ReadLine());
            double fare = 0;

            if (meter <= 0.5)
            {
                Console.WriteLine("The meter fare is $2.40.");
            }
            else
            {
                if (meter <= 9)
                {
                    fare = 2.4 + (meter - 0.5) * 0.04 * 10;
                    Console.WriteLine($"The meter fare is ${fare:0.00}.");
                }
                else
                {
                    fare = 2.4 + 85 * 0.04 + (meter - 9) * 0.05 * 10;
                    Console.WriteLine($"The meter fare is ${fare:0.00}.");
                }
            }

            Console.WriteLine("****************Question 5****************");
            Console.Write("Please enter a 3 digits number: ");
            int number = int.Parse(Console.ReadLine());
            int a = number % 10;
            int b = (number / 10) % 10;
            int c = (number / 100) % 10;
            int calnumber = a * a * a + b * b * b + c * c * c;
            if (number == calnumber)
            {
                Console.WriteLine("TRUE");
            }
            else
            {
                Console.WriteLine("FALSE");
            }


        }
    }
}
