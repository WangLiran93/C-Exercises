﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace D3Exercises
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("************Section D Question 1************");
            int number1 = 0;
            while (number1 != 88)
            {
                Console.Write("Please enter an integer: ");
                number1 = int.Parse(Console.ReadLine());
            }
            Console.WriteLine("Lucky you...");


            Console.WriteLine("************Section D Question 2************");
            Console.Write("Please enter the first integer: ");
            int inputA = int.Parse(Console.ReadLine());
            Console.Write("Please enter the second integer: ");
            int inputB = int.Parse(Console.ReadLine());
            int a = inputA;
            int b = inputB;

            while (inputA != inputB)
            {
                if (inputA < inputB)
                {
                    inputB = inputB - inputA;
                }
                else
                {
                    inputA = inputA - inputB;
                }
            }
            Console.WriteLine($"The highest common multiply is {inputA}");
            Console.WriteLine($"The lowest common multiply is {a * b / inputA}");

            Console.WriteLine("************Section D Question 3************");
            Random rnd = new Random();
            int number3 = rnd.Next(10);
            Console.WriteLine(number3);

            Console.Write("Please guess an integer from 0 to 9: ");
            int number3g = int.Parse(Console.ReadLine());
            int count = 0;

            while (number3 != number3g)
            {
                Console.Write("Try again: ");
                number3g = int.Parse(Console.ReadLine());
                count = count + 1;
            }

            if (count < 2)
            {
                Console.WriteLine("You are a Wizard!");
            }
            else if (count < 5)
            {
                Console.WriteLine("You are a good guess.");
            }
            else if (count >= 5)
            {
                Console.WriteLine("You are Lousy!");
            }


            Console.WriteLine("************Section D Question 4************");
            Console.Write("Please enter a number: ");
            double number4 = double.Parse(Console.ReadLine());

            if (number4 == 0)
            {
                Console.WriteLine("The square root of 0 is 0.000");
            }
            else
            {
                Random rnd4 = new Random();
                double G4 = 1 + rnd4.NextDouble() * (number4 - 1);

                while (Math.Abs(G4 * G4 - number4) > 0.00001)
                {
                    G4 = (G4 + number4 / G4) / 2;
                }
                Console.WriteLine($"The square root of {number4} is {G4:0.###}");
            }


            Console.WriteLine("************Section E Question 1************");
            Console.Write("Please enter an integer:");
            int numberE1 = int.Parse(Console.ReadLine());
            int totalE1 = 1;

            for (int i = 1; i <= numberE1; i++)
            {
                totalE1 = totalE1 * i;
            }

            Console.WriteLine($"Increment way: The factorial of {numberE1} is {totalE1}.");

            totalE1 = 1;
            for (int j = numberE1; j >= 1; j--)
            {
                totalE1 = totalE1 * j;
            }
            Console.WriteLine($"Increment way: The factorial of {numberE1} is {totalE1}.");

            Console.WriteLine("************Section E Question 2************");
            Console.WriteLine("NO\tINVERSE\t\tSQUARE ROOT\tSQUARE ");
            Console.WriteLine("-----------------------------------------------");
            for (int i = 1; i <= 10; i++)
            {
                double inverseE2 = 1.0 / i;
                double sqrtE2 = Math.Sqrt(i);
                double squareE2 = i * i;
                Console.WriteLine($"{i:0.0}   \t{inverseE2:0.0##}     \t{sqrtE2:0.0##}     \t{squareE2:0.0}");
            }

            Console.WriteLine("************Section E Question 3************");
            Console.Write("Please enter an integer: ");
            int numberE3 = int.Parse(Console.ReadLine());
            int flagE3 = 0;
            double sqrtE3 = Math.Sqrt(numberE3) + 1;

            for (int i = 2; i < sqrtE3; i++)
            {
                if (numberE3 % i == 0)
                {
                    flagE3 = 1;
                }
            }
            if (flagE3 == 1)
            {
                Console.WriteLine($"{numberE3} is not a prime number.");
            }
            else
            {
                Console.WriteLine($"{numberE3} is a prime number.");
            }


            Console.WriteLine("************Section E Question 4************");
            Console.Write("Please enter a number: ");
            int numberE4 = int.Parse(Console.ReadLine());
            int countE4 = 1;

            for (int i = 2; i < numberE4; i++)
            {
                if (numberE4 % i == 0)
                {
                    countE4 = countE4 + i;
                }
            }

            if (countE4 == numberE4)
            {
                Console.WriteLine($"{numberE4} is a Perfect number.");
            }
            else
            {
                Console.WriteLine($"{numberE4} is not a Perfect number.");
            }


            Console.WriteLine("************Section E Question 5************");
            for (int number = 5; number <= 10000; number++)
            {
                int flagE5 = 0;
                double sqrtE5 = Math.Sqrt(number) + 1;

                for (int i = 2; i < sqrtE5; i++)
                {
                    if (number % i == 0)
                    {
                        flagE5 = 1;
                    }
                }
                if (flagE5 == 0)
                {
                    Console.WriteLine(number);
                }
            }


            Console.WriteLine("************Section E Question 6************");
            for (int number = 5; number <= 10000; number++)
            {
                int countE6 = 1;
                for (int i = 2; i < number; i++)
                {
                    if (number % i == 0)
                    {
                        countE6 = countE6 + i;
                    }
                }

                if (countE6 == number)
                {
                    Console.WriteLine(number);
                }
            }


            Console.WriteLine("************Section F Question 1************");
            Console.Write("Please enter a phrase: ");
            string phraseF1 = Console.ReadLine();
            int lengthph = phraseF1.Length;
            string phraseF11 = phraseF1.ToLower();
            int countF1 = 0, counta = 0, counte = 0, counti = 0, counto = 0, countu = 0;

            for (int i = 0; i < lengthph; i++)
            {
                string letterF1 = phraseF11.Substring(i, 1);
                switch (letterF1)
                {
                    case "a":
                        counta = counta + 1;
                        break;
                    case "e":
                        counte = counte + 1;
                        break;
                    case "i":
                        counti++;
                        break;
                    case "o":
                        counto++;
                        break;
                    case "u":
                        countu++;
                        break;

                }
            }
            countF1 = counta + counte + counti + counto + countu;
            Console.WriteLine($"The total vowels are {countF1}, there are {counta} of a, {counte} of e, {counti} of i, {counto} of o and {countu} of u.");


            Console.WriteLine("************Section F Question 2************");
            Console.Write("Please enter a phrase: ");
            string phraseF2 = Console.ReadLine();
            string phraseF21 = phraseF2.ToLower();
            int lengthph2 = phraseF2.Length;
            int flagF2 = 0;

            for (int i = 0; i < lengthph2 / 2; i++)
            {
                if (phraseF21.Substring(i, 1) != phraseF21.Substring(lengthph2 - 1 - i, 1))
                {
                    flagF2 = 1;
                }
            }
            if (flagF2 == 1)
            {
                Console.WriteLine("It's not a palindrome.");
            }
            else
            {
                Console.WriteLine("It's a palindrome.");
            }


            Console.WriteLine("************Section F Question 3************");
            Console.Write("Please enter a sentence: ");
            string sentenceF3 = Console.ReadLine();
            string sentenceF31 = sentenceF3.ToLower();
            int lengthsenF3 = sentenceF3.Length;
            string sentenceF32 = "";
            int flagF3 = 0;

            for (int i = 0; i < lengthsenF3; i++)
            {
                if (sentenceF31[i] != ' ' && sentenceF31[i] != '.')
                {
                    sentenceF32 = sentenceF32 + sentenceF31[i];
                }
            }

            int lengthsenF32 = sentenceF32.Length;

            for (int i = 0; i < lengthsenF32; i++)
            {
                if (sentenceF32[i] != sentenceF32[lengthsenF32 - 1 - i])
                {
                    flagF3 = 1;
                }
            }

            if (flagF3 == 1)
            {
                Console.WriteLine("It's not a palindrome.");
            }
            else
            {
                Console.WriteLine("It's a palindrome.");
            }


            Console.WriteLine("************Section F Question 4************");
            Console.Write("Please enter a sentence: ");
            string sentenceF40 = Console.ReadLine();
            string sentenceF4 = sentenceF40.ToLower();
            int lengthF4 = sentenceF4.Length;
            string newsen4 = "";
            newsen4 = newsen4 + sentenceF4[0];
            newsen4 = newsen4.ToUpper();


            for (int i = 1; i < lengthF4; i++)
            {
                if (sentenceF4[i] == ' ')
                {
                    string newsen41 = "";
                    newsen41 = newsen41 + sentenceF4[i + 1];
                    newsen4 = newsen4 + " " + newsen41.ToUpper();
                    i++;
                }
                else
                {
                    newsen4 = newsen4 + sentenceF4[i];
                }
            }
            Console.WriteLine(newsen4);

            /*Another method*/
            Console.Write("Please enter a sentence: ");
            string SFstr = Console.ReadLine().ToLower();
            string[] strArr = SFstr.Split();
            for (int i = 0; i < strArr.Length; i++)
            {
                if (strArr[i] != " ")
                {
                    strArr[i] = strArr[i].Substring(0, 1).ToUpper() + strArr[i].Substring(1);
                }
            }
            Console.WriteLine(string.Join(" ", strArr));


            Console.WriteLine("************Section F Question 5************");
            string[] Name = new string[] { "John", "Venkat", "Mary", "Victor", "Betty" };
            int[] Marks = new int[] { 63, 29, 75, 82, 55 };

            for (int green = 0; green < Marks.Length - 1; green++)
            {
                for (int red = green + 1; red < Marks.Length; red++)
                {
                    if (Marks[red] > Marks[green])
                    {
                        //swap
                        int temp = Marks[red];
                        Marks[red] = Marks[green];
                        Marks[green] = temp;
                        string temp2 = Name[red];
                        Name[red] = Name[green];
                        Name[green] = temp2;
                    }
                }
            }
            Console.WriteLine("Student rank in descending order of the Marks: ");
            PrintArray2(Name);
            PrintArray(Marks);

            for (int green = 0; green < Name.Length - 1; green++)
            {
                for (int red = green + 1; red < Name.Length; red++)
                {
                    int compare = Name[green].CompareTo(Name[red]);
                    if (compare == 1)
                    {
                        //swap
                        int temp = Marks[red];
                        Marks[red] = Marks[green];
                        Marks[green] = temp;
                        string temp21 = Name[red];
                        Name[red] = Name[green];
                        Name[green] = temp21;
                    }
                }
            }
            Console.WriteLine("Student rank in alphabetically: ");
            PrintArray2(Name);
            PrintArray(Marks);


            Console.WriteLine("************Section F Question 6************");
            Console.Write("Enter a matriculation number: ");
            string MatricNo = Console.ReadLine().ToUpper();
            int sum = 0;

            if (MatricNo.Length != 7)
            {
                Console.WriteLine("Invalid");
            }
            else
            {
                for (int i = 1; i < 6; i++)
                {
                    int num0 = int.Parse(MatricNo.Substring(i, 1));
                    int num = num0 * (7 - i);
                    sum = sum + num;
                }

                int reminder = sum % 5;
                if ((reminder == 0 && MatricNo.Substring(6, 1) == "O") ||
                        (reminder == 1 && MatricNo.Substring(6, 1) == "P") ||
                        (reminder == 2 && MatricNo.Substring(6, 1) == "Q") ||
                        (reminder == 3 && MatricNo.Substring(6, 1) == "R") ||
                        (reminder == 4 && MatricNo.Substring(6, 1) == "S"))
                {
                    Console.WriteLine("Valid");
                }
            }







        }

        static void PrintArray(int[] A)
        {
            for (int i = 0; i < A.Length; i++)
            {
                Console.Write(A[i] + "\t");
            }
            Console.WriteLine();
        }

        static void PrintArray2(string[] A)
        {
            for (int i = 0; i < A.Length; i++)
            {
                Console.Write(A[i] + "\t");
            }
            Console.WriteLine();
        }
    }
}
