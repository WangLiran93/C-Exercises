﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace D1Exercises
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Part A Question 1:");
            Console.WriteLine("Wang Liran");
            Console.WriteLine("wangliran@u.nus.edu");


            Console.WriteLine("Part A Question 2:");
            Console.Write("Please enter you name:");
            Console.WriteLine($"Good Morning {Console.ReadLine()}");


            Console.WriteLine("Part A Question 3:");
            Console.Write("Please enter an integer: ");
            int a = int.Parse(Console.ReadLine());
            Console.WriteLine($"The square of {a} is {a * a}");


            Console.WriteLine("Part A Question 4:");
            Console.Write("Please enter a double precesion number: ");
            double b = double.Parse(Console.ReadLine());
            Console.WriteLine($"The square of {b} is {b * b}");


            Console.WriteLine("Part A Question 5:");
            Console.Write("Please enter a double precesion number: ");
            double c = double.Parse(Console.ReadLine());
            Console.WriteLine($"The square of {c} is {c.ToString("F2")}");



            Console.WriteLine("Part B Question 1:");
            Console.Write("Please enter a double precesion number: ");
            double d = double.Parse(Console.ReadLine());
            Console.WriteLine($"The square of {d} is {Math.Sqrt(d).ToString("0.###")}");


            Console.WriteLine("Part B Question 2:");
            Console.Write("Please enter a double precesion number: ");
            double e = Math.Sqrt(double.Parse(Console.ReadLine()));
            Console.WriteLine($"The square of {e} is {e.ToString("F3")}");


            Console.WriteLine("Part B Question 3:");
            Console.Write("Please enter your salary: ");
            double f = double.Parse(Console.ReadLine());
            double ff = f * (1 + 0.1 + 0.03);
            Console.WriteLine($"The total income is {ff.ToString("C2")}");


            Console.WriteLine("Part B Question 4:");
            Console.Write("Please enter Centigrade(C): ");
            double g = double.Parse(Console.ReadLine()) * 1.8 + 32;
            Console.WriteLine("The Fahreheit(F) is " + g.ToString("F0"));


            Console.WriteLine("Part B Question 5:");
            Console.Write("Please enter value X: ");
            double h = double.Parse(Console.ReadLine());
            double hh = 5 * h * h - 4 * h + 3;
            Console.WriteLine("The value Y is " + hh);


            Console.WriteLine("Part B Question 6:");
            Console.Write("Please enter value X1: ");
            double x1 = double.Parse(Console.ReadLine());
            Console.Write("Please enter value Y1: ");
            double y1 = double.Parse(Console.ReadLine());
            Console.Write("Please enter value X2: ");
            double x2 = double.Parse(Console.ReadLine());
            Console.Write("Please enter value Y2: ");
            double y2 = double.Parse(Console.ReadLine());
            double distance = Math.Sqrt((x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1));
            Console.WriteLine("The distance of (X1,Y1) and (X2,Y2) is  " + distance);


            Console.WriteLine("Part B Question 7:");
            Console.Write("Please enter travel distance: ");
            double j = 2.4 + double.Parse(Console.ReadLine()) * 0.4;
            Console.WriteLine("The total fare is  " + j);


            Console.WriteLine("Part B Question 8:");
            Console.Write("Please enter travel distance: ");
            double jj = 2.4 + double.Parse(Console.ReadLine()) * 0.4;
            Console.WriteLine("The total fare rounded is  " + jj.ToString("#.#") + "0");


            Console.WriteLine("Part B Question 9:");
            Console.Write("Please enter travel distance: ");
            double k = 2.4 + double.Parse(Console.ReadLine()) * 0.4;
            double kk = Math.Ceiling(k * 10) / 10;
            Console.WriteLine("The total fare rounded upwards is  " + kk);


            Console.WriteLine("Part B Question 10:");
            Console.Write("Please enter the length of side a: ");
            double lengtha = double.Parse(Console.ReadLine());
            Console.Write("Please enter the length of side b: ");
            double lengthb = double.Parse(Console.ReadLine());
            Console.Write("Please enter the length of side c: ");
            double lengthc = double.Parse(Console.ReadLine());
            double s = (lengtha + lengthb + lengthc) / 2;
            double area = Math.Sqrt(s * (s - lengtha) * (s - lengthb) * (s - lengthc));
            Console.WriteLine("The are of a triangle is  " + area);

        }
    }
}
