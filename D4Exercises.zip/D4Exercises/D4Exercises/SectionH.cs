﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
delegate double DoubleOps(double x);

namespace D4Exercises
{
    class SectionH
    {
        static void Main(string[] args)
        {
            ///*Section H*/
            //Console.WriteLine("------------Section H Question 1------------");
            //Console.Write("Enter a number: ");
            //int number = ReadInteger(Console.ReadLine());

            //Console.WriteLine("------------Section H Question 2------------");
            //int[] array = { 1, 2, 3, 4, 5 };
            //PrintArray(array);

            //Console.WriteLine("------------Section H Question 3------------");
            //Console.Write("Please enter the Sentence 1: ");
            //string s1 = Console.ReadLine();
            //Console.Write("Please enter the Sentence 2: ");
            //string s2 = Console.ReadLine();
            //if (InString(s1, s2))
            //{
            //    Console.WriteLine("True");
            //}
            //else
            //{
            //    Console.WriteLine("False");
            //}


            //Console.WriteLine("------------Section H Question 4------------");
            //Console.Write("Please enter the Sentence 1: ");
            //string s1 = Console.ReadLine();
            //Console.Write("Please enter the Sentence 2: ");
            //string s2 = Console.ReadLine();
            //Console.WriteLine(FindWord(s1, s2));


            //Console.WriteLine("------------Section H Question 5------------");
            //Console.Write("Please enter a number: ");
            //int number = int.Parse(Console.ReadLine());
            //Console.WriteLine(Hex(number));
            //Console.WriteLine("Print out the Hex of all numbers 1 to 100: ");
            //for (int i = 1; i <= 100; i++)
            //{
            //    Console.Write(Hex(i) + " ");
            //}


            //Console.WriteLine("------------Section H Question 6------------");
            //Console.Write("Please enter a string: ");
            //string s = Console.ReadLine();
            //Console.Write("Please enter a character to find: ");
            //char c1 = char.Parse(Console.ReadLine());
            //Console.Write("Please enter a character to replace: ");
            //char c2 = char.Parse(Console.ReadLine());
            //Console.WriteLine(Substitute(s, c1, c2));


            //Console.WriteLine("------------Section H Question 7------------");
            //int[] arr = new int[12];
            //SetArray(arr, 5);
            //PrintArray(arr);


            //Console.WriteLine("------------Section H Question 8------------");
            //int[] arr = new int[] { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
            //int[] newarr = ResizeArray(arr, 5);
            //PrintArray(newarr);


            //Console.WriteLine("------------Section H Question 9------------");
            //for (int i = 5; i <= 10000; i++)
            //{
            //    if (IsPrime(i))
            //    {
            //        Console.Write(i + " ");
            //    }
            //}


            //Console.WriteLine("------------Section H Question 10------------");
            //int[,] A = { { 1, 2 }, { 3, 4 }, { 5, 6 }, { 7, 8 } };
            //int[,] B = { { 11, 12, 13 }, { 14, 15, 16 } };
            //int[,] matrix = MatrixMultiply(A, B);
            //SectionG.Print2DArray(matrix);

            //Console.WriteLine("------------Section H Question 11------------");
            //Random rnd = new Random();
            //int size = rnd.Next(5, 10);
            //double[] Array = new double[size];
            //for (int i = 0; i < size; i++)
            //{
            //    Array[i] = rnd.Next(100);
            //}
            //DoubleOps sqrt = Sqrt;
            //DoubleOps square = Square;
            //SectionG.PrintArray2(Array);
            //double[] arrSqrt = ProcessArray(Array, sqrt);
            //SectionG.PrintArray2(arrSqrt);
            //double[] arrSquare = ProcessArray(Array, square);
            //SectionG.PrintArray2(arrSquare);

        }

        static int ReadInteger(string input)
        {
            int result = 0;
            while (!int.TryParse(input, out result))
            {
                Console.Write("Enter a number: ");
                input = Console.ReadLine();
            }
            return result;
        }

        static void PrintArray(int[] x)
        {
            for (int i = 0; i < x.Length; i++)
            {
                Console.Write(x[i]);
                if (i != x.Length - 1)
                {
                    Console.Write("\t");
                }
                else
                {
                    Console.WriteLine();
                }
            }
        }

        static bool InString(string s1, string s2)
        {
            int length = s2.Length;
            string S1 = s1.ToLower();
            string S2 = s2.ToLower();
            if (s1.Length < length)
            {
                return false;
            }
            for (int i = 0; i < s1.Length - length + 1; i++)
            {
                if (S2 == S1.Substring(i, length))
                {
                    return true;
                }
            }
            return false;
        }

        static int FindWord(string S1, string S2)
        {
            string s1 = S1.ToLower();
            string s2 = S2.ToLower();
            if (s1.Length < s2.Length)
            {
                return -1;
            }
            for (int i = 0; i < s1.Length - s2.Length + 1; i++)
            {
                if (s2 == s1.Substring(i, s2.Length))
                {
                    return i;
                }
            }
            return -1;
        }

        static string Hex(int integer)
        {
            int reminder = integer % 16;
            int multiple = integer / 16;
            if (reminder <= 9)
            {
                return $"{multiple * 10 + reminder}";
            }

            switch (reminder)
            {
                case 10:
                    return $"{multiple:#}A";
                case 11:
                    return $"{multiple:#}B";
                case 12:
                    return $"{multiple:#}C";
                case 13:
                    return $"{multiple:#}D";
                case 14:
                    return $"{multiple:#}E";
                case 15:
                    return $"{multiple:#}F";
            }
            return "";
        }

        static string Substitute(string s, char c1, char c2)
        {
            string output = "";
            for (int i = 0; i < s.Length; i++)
            {
                if (c1 == char.Parse(s.Substring(i, 1)))
                {
                    output = output + c2;
                    i++;
                }
                output = output + s.Substring(i, 1);
            }
            return output;
        }

        static void SetArray(int[] arr, int value)
        {
            for (int i = 0; i < arr.Length; i++)
            {
                arr[i] = value;
            }
        }

        static int[] ResizeArray(int[] arr, int newSize)
        {
            int[] newArray = new int[newSize];
            if (newSize < arr.Length)
            {
                for (int i = 0; i < newSize; i++)
                {
                    newArray[i] = arr[i];
                }
            }
            else
            {
                for (int i = 0; i < arr.Length; i++)
                {
                    newArray[i] = arr[i];
                }
            }
            return newArray;
        }

        static bool IsPrime(int n)
        {
            for (int i = 2; i < n; i++)
            {
                if (n % i == 0)
                {
                    return false;
                }
            }
            return true;
        }


        static int[,] MatrixMultiply(int[,] A, int[,] B)
        {
            int rowA = A.GetLength(0);
            int colA = A.GetLength(1);
            int rowB = B.GetLength(0);
            int colB = B.GetLength(1);
            int[,] empty = new int[0, 0];
            if (colA != rowB)
            {
                return empty;
            }
            int[,] X = new int[rowA, colB];
            for (int i = 0; i < rowA; i++)
            {
                for (int j = 0; j < colB; j++)
                {
                    for (int a = 0; a < colA; a++)
                    {
                        X[i, j] = X[i, j] + A[i, a] * B[a, j];
                    }
                }
            }
            return X;
        }


        static double[] ProcessArray(double[] arr, DoubleOps ops)
        {
            double[] Array = new double[arr.Length];
            for (int i = 0; i < arr.Length; i++)
            {
                Array[i] = ops(arr[i]);
            }
            return Array;
        }

        static double Sqrt(double x)
        {
            return Math.Sqrt(x);
        }

        static double Square(double x)
        {
            double xx = x * x;
            return xx;
        }
    }
}
