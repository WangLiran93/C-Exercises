﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace D4Exercises
{
    class SectionG
    {
        static void Main(string[] args)
        {
            ///*Section G*/
            //Console.WriteLine("------------Section G Question 1------------");
            //string[] Month = new string[] { "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December" };
            //int[] sales = new int[12];
            //Console.Write("Please enter the sales for 12 months: ");
            //for(int i = 0; i < 12; i++)
            //{
            //    sales[i] = int.Parse(Console.ReadLine());
            //} 
            //int count = 0;

            ///*Find the Maximum Sales*/
            //int maxsales = sales[0];
            //for (int i = 1; i < 12; i++)
            //{
            //    if (sales[i] > maxsales)
            //    {
            //        maxsales = sales[i];
            //    }
            //}
            ///*Print the month with Maximum Sales*/
            //Console.Write("The month when Maximum sales is recorded is ");
            //for (int i = 0; i < 12; i++)
            //{
            //    if (sales[i] == maxsales)
            //    {
            //        Console.Write(Month[i] + " ");
            //    }
            //}
            //Console.WriteLine();

            ///*Find the Minimum Sales*/
            //int minsales = sales[0];
            //for (int i = 1; i < 12; i++)
            //{
            //    if (sales[i] < minsales)
            //    {
            //        minsales = sales[i];
            //    }
            //}
            //Console.Write("The month when Minimum sales is recorded is ");
            //for (int i = 0; i < 12; i++)
            //{
            //    if (sales[i] == minsales)
            //    {
            //        Console.Write(Month[i] + " ");
            //    }
            //}
            //Console.WriteLine();

            //for (int i = 0; i < 12; i++)
            //{
            //    count = count + sales[i];
            //}

            //Console.WriteLine($"The average monthly sales for the year is {count / 12}");


            //Console.WriteLine("------------Section G Question 2------------");

            //int[] Array = new int[] { 1, 45, 43, 65, 27, 66 };
            //for (int i = 0; i < Array.Length - 1; i++)
            //{
            //    for (int j = i; j < Array.Length; j++)
            //    {
            //        if (Array[j] > Array[i])
            //        { 
            //            /*swap*/
            //            int temp = Array[j];
            //            Array[j] = Array[i];
            //            Array[i] = temp;
            //        }
            //    }
            //}
            //PrintArray(Array);


            //Console.WriteLine("------------Section G Question 3------------");
            //int[,] marks = new int[,] { { 56, 84, 68, 29},{ 94, 73, 31, 96},{ 41, 63 ,36, 90},{ 99, 9, 18, 17 },
            //                            { 62 ,3 ,65 ,75},{40 ,96 ,53 ,23 },{ 81, 15, 27, 30},{ 21, 70, 100, 22},
            //                            { 88, 50, 13, 12},{ 48, 54, 52, 78},{64, 71, 67, 25 },{16, 93, 46, 72 }};

            //int row = marks.GetLength(0);
            //int col = marks.GetLength(1);
            //int[] total = new int[row];
            //Console.WriteLine("The total marks obtained for each student is: ");
            //for (int i = 0; i < row; i++)
            //{
            //    int temp = 0;
            //    for (int j = 0; j < col; j++)
            //    {  
            //        temp = temp + marks[i, j];
            //    }
            //    total[i] = temp;
            //}
            //PrintArray(total);

            //double[] average = new double[row];
            //Console.WriteLine("The average marks for each student is: ");
            //for (int i = 0; i < row; i++)
            //{
            //    average[i] = (double)total[i] / col;
            //}
            //PrintArray2(average);

            //double[] deviation = new double[row];
            //Console.WriteLine("The deviation marks for each student is: ");  
            //for(int i = 0; i < row; i++)
            //{
            //    double temp = 0;
            //    for (int j = 0; j < col; j++)
            //    {
            //        temp = temp + Math.Pow(marks[i, j] - average[i], 2) / col;
            //    }
            //    deviation[i] = Math.Sqrt(temp);
            //}
            //PrintArray2(deviation);



            //Console.WriteLine("------------Section G Question 4------------");
            //Random rnd = new Random();
            //int size = rnd.Next(5, 15);
            //int[] Array = new int[size];
            //for (int i = 0; i < size; i++)
            //{
            //    Array[i] = rnd.Next(100);
            //}
            //PrintArrayFormat(Array);


            //Console.WriteLine("------------Section G Question 5------------");
            //Random rnd = new Random();
            //int size = rnd.Next(5, 15);
            //int[] Array = new int[size];
            //for (int i = 0; i < size; i++)
            //{
            //    Array[i] = rnd.Next(100);
            //}
            //Console.Write("Enter a number: ");
            //int number = int.Parse(Console.ReadLine());
            //int flag = 0;
            //for (int i = 0; i < size; i++)
            //{
            //    if (number == Array[i])
            //    {
            //        Console.WriteLine($"Number {number} is found in the array at the element no {i}.");
            //        flag = 1;
            //    }
            //}
            //if (flag == 0)
            //{
            //    Console.WriteLine("No number is found in the array.");
            //}


            //Console.WriteLine("------------Section G Question 6------------");
            //Random rnd = new Random();
            //int size = rnd.Next(5, 15);
            //int[] Array = new int[size];
            //for (int i = 0; i < size; i++)
            //{
            //    Array[i] = rnd.Next(100);
            //}
            //PrintArrayFormat(Array);
            //Console.WriteLine();
            ///*Ascending order*/
            //for(int i = 0; i < size - 1; i++)
            //{
            //    for(int j = i + 1; j < size; j++)
            //    {
            //        if(Array[j] < Array[i])
            //        {
            //            int temp = Array[i];
            //            Array[i] = Array[j];
            //            Array[j] = temp;
            //        }
            //    }
            //}
            //PrintArrayFormat(Array);


            //Console.WriteLine("------------Section G Question 7------------");
            //string[] name = new string[] { "Alice", "Bob", "Charlie", "Dennis", "Eli", "Frank", "Gina" };
            //int[] score = new int[] { 100, 90, 120, 80, 76, 66, 88 };
            //for(int i = 0; i < score.Length - 1; i++)
            //{
            //    for(int j = i + 1; j < score.Length; j++)
            //    {
            //        if(score[j] < score[i])
            //        {
            //            int temp = score[i];
            //            score[i] = score[j];
            //            score[j] = temp;
            //            string temp2 = name[i];
            //            name[i] = name[j];
            //            name[j] = temp2;
            //        }
            //    }
            //}
            //Console.Write("Name\t");
            //PrintArray3(name);
            //Console.Write("Socre\t");
            //PrintArray(score);


            //Console.WriteLine("------------Section G Question 8------------");
            //Random rnd = new Random();
            //int row = rnd.Next(3, 15);
            //int col = rnd.Next(3, 15);
            //int[,] array = new int[row, col];
            //for (int i = 0; i < row; i++)
            //{
            //    for (int j = 0; j < col; j++)
            //    {
            //        array[i, j] = rnd.Next(100);
            //    }
            //}
            //Print2DArray(array);
            //Console.Write("Enter a number: ");
            //int number = int.Parse(Console.ReadLine());
            //int flag = 0;
            //for (int i = 0; i < row; i++)
            //{
            //    for (int j = 0; j < col; j++)
            //    {
            //        if (number == array[i, j])
            //        {
            //            Console.WriteLine($"Number {number} is found in the array at [{i + 1},{j + 1}]");
            //            flag = 1;
            //        }
            //    }
            //}
            //if (flag == 0)
            //{
            //    Console.WriteLine("The number is not found in the array.");
            //}

        }

        static void PrintArrayFormat(int[] x)
        {
            Console.Write("[");
            for (int i = 0; i < x.Length; i++)
            {
                Console.Write(x[i]);
                if (i != x.Length - 1)
                {
                    Console.Write(",");
                }
                else
                {
                    Console.Write("]");
                }
            }
        }

        public static void PrintArray(int[] x)
        {
            for (int i = 0; i < x.Length; i++)
            {
                Console.Write(x[i]);
                if (i != x.Length - 1)
                {
                    Console.Write("\t");
                }
                else
                {
                    Console.WriteLine();
                }
            }
        }

        public static void PrintArray2(double[] x)
        {
            for (int i = 0; i < x.Length; i++)
            {
                Console.Write($"{x[i]:0.###}");
                if (i != x.Length - 1)
                {
                    Console.Write("\t");
                }
                else
                {
                    Console.WriteLine();
                }
            }
        }

        static void PrintArray3(string[] x)
        {
            for (int i = 0; i < x.Length; i++)
            {
                Console.Write(x[i]);
                if (i != x.Length - 1)
                {
                    Console.Write("\t");
                }
                else
                {
                    Console.WriteLine();
                }
            }
        }

        public static void Print2DArray(int[,] x)
        {
            int row = x.GetLength(0);
            int col = x.GetLength(1);
            Console.WriteLine();
            for (int i = 0; i < row; i++)
            {
                for (int j = 0; j < col; j++)
                {
                    Console.Write(x[i, j]);
                    if (j != col - 1)
                    {
                        Console.Write("\t");
                    }
                    else
                    {
                        Console.WriteLine();
                    }
                }

            }
        }
    }
}
